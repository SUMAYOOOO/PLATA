# Contributing to SUMAYÕ

1. Fork the repo
2. Create a branch: git checkout -b feature/my-feature
3. Commit your changes and open a PR

Be polite and add tests for new features.
