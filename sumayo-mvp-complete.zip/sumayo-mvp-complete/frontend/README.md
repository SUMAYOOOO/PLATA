# Frontend

Install dependencies:
npm install

Run dev:
npm run dev
