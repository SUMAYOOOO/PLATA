# Backend

Install dependencies:
npm install

Prisma:
npx prisma generate
npx prisma migrate dev --name init
npm run seed

Run dev:
npm run start:dev
