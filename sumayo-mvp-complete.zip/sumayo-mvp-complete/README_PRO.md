README completo generado automáticamente. Incluye logo, badges, mermaid, instructions, etc.
See README.md for quick start.
